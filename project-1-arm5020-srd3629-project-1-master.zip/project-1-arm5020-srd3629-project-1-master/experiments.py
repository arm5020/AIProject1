# experiments.py
# Summer DiStefano (srd3629) & Adam Mercer (arm5020)
# CSCI331 - Project #1 - Analyzing Different AI Algorithms

import sys
import numpy as np
import matplotlib.pyplot as plt
import time
import asteroids_exp
import asteroid_tree
import asteroids_sa
import asteroids_ga

# Mapping of specific moves in the game to a specific letter label.
MOVES = {'q': (-1, -1), 'w': (0, -1), 'e': (1, -1), 'a': (-1, 0),
         'd': (1, 0), 'z': (-1, 1), 'x': (0, 1), 'c': (1, 1), 's': (0, 0)}

ROW_HEADERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]


def create_table(dataset, table_label, file_label):
    """ Creates a table given a specific data set and saves it in a pdf file. """
    column_headers = ['Tree Search', 'Simulated Annealing', 'Genetic Algorithms']
    plt.figure(linewidth=2, tight_layout={'pad': 1})
    table = plt.table(
        cellText=dataset,
        rowLabels=ROW_HEADERS,
        rowLoc='right',
        colLabels=column_headers,
        loc='center')
    table.scale(1, 1.5)
    ax = plt.gca()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    plt.box(on=None)
    plt.suptitle(table_label + " at End of Game")
    plt.draw()
    plt.savefig(file_label + '.png')


def create_graph(dataset, graph_label, file_label):  # FIXME - Doesn't work right now.
    """ Creates a graph given a specific data set and saves it in a pdf file. """
    game_types = ['Tree Search', 'Simulated Annealing', 'Genetic Algorithms']
    x = np.arange(5)
    plt.bar(x, dataset, align='center')
    plt.xticks(x, game_types)
    plt.ylabel(graph_label)
    plt.table(graph_label + " at End of Game")
    plt.savefig(file_label + 'png')


def run_game(game_num, datasets):
    """ Run all three algorithms on a specific game file and fill in the data sets. """
    # Tree search
    print("Running tree search on game " + str(game_num) + "...")
    start_time = time.time()
    t = asteroid_tree.Search_Agent()
    move_state = t.state
    path = t.run()
    end_time = time.time()
    for step in path:
        xv, yv = MOVES[step[0]]
        move_state = asteroids_exp.move(t.state, xv, yv, step[1], t.window_width, t.window_height, t.args,
                                        lambda x: asteroids_exp.render(t.view, x))
    t_fuel_left = move_state.ship.fuel
    t_game_time = len(path)
    t_system_time = end_time - start_time

    # Simulated Annealing
    print("Running simulated annealing on game " + str(game_num) + "...")
    start_time = time.time()
    sa = asteroids_sa.SA_Agent()
    move_state = sa.env_state
    path = sa.solution
    end_time = time.time()
    for step in path:
        xv, yv = MOVES[step[0]]
        move_state = asteroids_exp.move(sa.env_state, xv, yv, step[1], sa.window_width, sa.window_height, sa.args,
                                        lambda x: asteroids_exp.render(sa.view, x))
    sa_fuel_left = move_state.ship.fuel
    sa_game_time = len(path)
    sa_system_time = end_time - start_time

    # Genetic Algorithm
    print("Running genetic algorithms on game " + str(game_num) + "...")
    start_time = time.time()
    ga = asteroids_ga.GAAgent()
    move_state = ga.env_state
    path = ga.solution.solution
    end_time = time.time()
    for step in path:
        xv, yv = MOVES[step[0]]
        move_state = asteroids_exp.move(ga.env_state, xv, yv, step[1], ga.window_width, ga.window_height, ga.args,
                                        lambda x: asteroids_exp.render(ga.view, x))
    ga_fuel_left = move_state.ship.fuel
    ga_game_time = len(path)
    ga_system_time = end_time - start_time

    # Fill in fuel left, game time and system time data sets.
    datasets[0].append([t_fuel_left, sa_fuel_left, ga_fuel_left])
    datasets[1].append([t_game_time, sa_game_time, ga_game_time])
    datasets[2].append([t_system_time, sa_system_time, ga_system_time])


def main():
    datasets = [[], [], []]  # Data sets =>  0: fuel left, 1: game time,  2: system time

    # For each game file, run it and fill in the data sets.
    for game_num in range(0, 25):
        sys.argv[1] = "-i"
        sys.argv[2] = "asteroid_game_" + str(game_num) + ".json"
        run_game(game_num, datasets)

    # Create tables for each data set.
    create_table(datasets[0], "Fuel Left", "fuel_left")
    create_table(datasets[1], "Game Time", "game_time")
    create_table(datasets[2], "System Time", "system_time")

    # Create a graph for each data set.
    # create_graph(datasets[0], "Fuel Left", "fuel_left")
    # create_graph(datasets[1], "Game Time", "game_time")
    # create_graph(datasets[2], "System Time", "system_time")


main()
